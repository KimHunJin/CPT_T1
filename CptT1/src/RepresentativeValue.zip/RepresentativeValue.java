
public class RepresentativeValue {
	private int index;
	private int weight;
	private String name;
	private String constraints;
	private int state;
	private RepresentativeValue prev;
	private RepresentativeValue next;
	
	public int getIndex()
	{
		return index;
	}
	
	public void setIndex(int num)
	{
		index=num;
	}
	
	public int getWeight()
	{
		return weight;
	}
	
	public void setWeight(int num)
	{
		weight=num;
	}
	
	public String getConstraints()
	{
		return constraints;
	}
	
	public void setConstraints(String text)
	{
		constraints= text;
	}
	
	public int getState()
	{
		return state;
	}
	
	public void setState(int num)
	{
		state=num;
	}
	
	public RepresentativeValue getPrev()
	{
		return prev;
	}
	
	public void setPrev(RepresentativeValue node)
	{
		prev=node;
	}
	
	public RepresentativeValue getNext()
	{
		return next;
	}
	
	public void setNext(RepresentativeValue node)
	{
		next=node;
	}

}
